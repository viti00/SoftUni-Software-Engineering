﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-2R3NOAT\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
