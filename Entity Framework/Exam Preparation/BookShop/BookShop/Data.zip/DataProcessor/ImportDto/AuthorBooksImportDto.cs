﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.DataProcessor.ImportDto
{
    public class AuthorBooksImportDto
    {
        public int Id { get; set; }
    }
}
