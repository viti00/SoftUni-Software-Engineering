﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftJail.Data.Models.Enums
{
    public enum Position
    {
        Overseer,
        Guard, 
        Watcher, 
        Labour
    }
}
